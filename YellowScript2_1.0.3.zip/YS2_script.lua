-- [[ YELLOW SCRIPT 2 (YS2) RECREATION ]] --
-- Cảnh báo: Chỉ hoạt động Server-Side nếu game có lỗ hổng (RemoteEvent/Backdoor)

local L_Services = {
    RunService = game:GetService("RunService"),
    UserInputService = game:GetService("UserInputService"),
    TweenService = game:GetService("TweenService"),
    CoreGui = game:GetService("CoreGui")
}

-- 1. TẠO GIAO DIỆN (GUI)
local YS2_Gui = Instance.new("ScreenGui", L_Services.CoreGui)
local MainFrame = Instance.new("Frame", YS2_Gui)
MainFrame.Size = UDim2.new(0, 250, 0, 320)
MainFrame.Position = UDim2.new(0.5, -125, 0.5, -160)
MainFrame.BackgroundColor3 = Color3.fromRGB(30, 30, 30)
MainFrame.BorderSizePixel = 2
MainFrame.BorderColor3 = Color3.fromRGB(255, 255, 0) -- Viền vàng đặc trưng

local Title = Instance.new("TextLabel", MainFrame)
Title.Size = UDim2.new(1, 0, 0, 30)
Title.BackgroundColor3 = Color3.fromRGB(255, 255, 0)
Title.Text = "YELLOW SCRIPT² [SS]"
Title.TextColor3 = Color3.fromRGB(0, 0, 0)
Title.Font = Enum.Font.SourceSansBold
Title.TextSize = 18

-- 2. HÀM KÉO THẢ (DRAGGABLE) MƯỢT MÀ
local dragging, dragInput, dragStart, startPos
MainFrame.InputBegan:Connect(function(input)
    if input.UserInputType == Enum.UserInputType.MouseButton1 then
        dragging = true; dragStart = input.Position; startPos = MainFrame.Position
    end
end)
L_Services.UserInputService.InputChanged:Connect(function(input)
    if dragging and input.UserInputType == Enum.UserInputType.MouseMovement then
        local delta = input.Position - dragStart
        MainFrame.Position = UDim2.new(startPos.X.Scale, startPos.X.Offset + delta.X, startPos.Y.Scale, startPos.Y.Offset + delta.Y)
    end
end)
L_Services.UserInputService.InputEnded:Connect(function(input)
    if input.UserInputType == Enum.UserInputType.MouseButton1 then dragging = false end
end)

-- 3. HÀM THỰC THI LỆNH (SERVER-SIDE CORE)
-- Bạn cần tìm Remote hở và thay thế vào đây
local function ExecuteSS(code)
    -- Ví dụ: game.ReplicatedStorage.ExecuteRemote:FireServer(code)
    -- Nếu không có Remote SS, lệnh này chỉ chạy Local (mình bạn thấy)
    local func, err = loadstring(code)
    if func then func() else warn(err) end 
end

-- 4. DANH SÁCH CÁC NÚT TÍNH NĂNG
local function CreateButton(name, pos, color, scriptText)
    local btn = Instance.new("TextButton", MainFrame)
    btn.Size = UDim2.new(0.9, 0, 0, 35)
    btn.Position = pos
    btn.Text = name
    btn.BackgroundColor3 = color
    btn.Font = Enum.Font.SourceSans
    btn.TextSize = 16
    
    btn.MouseButton1Click:Connect(function()
        ExecuteSS(scriptText)
    end)
end

-- TÍNH NĂNG 1: SPAM DECAL (Dán ảnh khắp map)
CreateButton("Spam Decals", UDim2.new(0.05, 0, 0.15, 0), Color3.fromRGB(60, 60, 60), [[
    local id = "12114344351" -- Thay ID ảnh của bạn ở đây
    for _, v in pairs(game.Workspace:GetDescendants()) do
        if v:IsA("Part") then
            local d = Instance.new("Decal", v)
            d.Texture = "rbxassetid://" .. id
            d.Face = Enum.NormalId.Front
            -- Copy ra 6 mặt nếu muốn bao phủ hoàn toàn
        end
    end
]])

-- TÍNH NĂNG 2: SKYBOX (Thay bầu trời)
CreateButton("Change Skybox", UDim2.new(0.05, 0, 0.3, 0), Color3.fromRGB(60, 60, 60), [[
    local sky = Instance.new("Sky", game.Lighting)
    sky.SkyboxBk = "rbxassetid://12114344351"; sky.SkyboxDn = "rbxassetid://12114344351" -- Thay ID
    game.Lighting.TimeOfDay = "00:00:00"
]])

-- TÍNH NĂNG 3: FOG (Sương mù mù mịt)
CreateButton("Extreme Fog", UDim2.new(0.05, 0, 0.45, 0), Color3.fromRGB(60, 60, 60), [[
    game.Lighting.FogEnd = 50
    game.Lighting.FogColor = Color3.new(1, 0, 0) -- Sương đỏ
]])

-- TÍNH NĂNG 4: LOUD MUSIC (Phát nhạc toàn server)
CreateButton("Play Loud Music", UDim2.new(0.05, 0, 0.6, 0), Color3.fromRGB(60, 60, 60), [[
    local s = Instance.new("Sound", game.Workspace)
    s.SoundId = "rbxassetid://1835337424"
    s.Volume = 10
    s.Looped = true
    s:Play()
]])

-- TÍNH NĂNG 5: DESTROY MAP (Xóa sạch mọi thứ)
CreateButton("⚠️ DESTROY MAP", UDim2.new(0.05, 0, 0.75, 0), Color3.fromRGB(150, 0, 0), [[
    game.Workspace:ClearAllChildren()
]])

print("YellowScript² Loaded Successfully!")
